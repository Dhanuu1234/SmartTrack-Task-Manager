# 📋 SmartTrack — Employee Task Management System

> **Full-Stack Web Application** | Python · Flask · SQLite · Bootstrap 5  
> **Author:** Dhanshree Zagde | [LinkedIn](https://linkedin.com/in/dhanshree-zagde27) | [Portfolio](https://github.com/dhanshree-zagde)

---

## 🚀 Live Demo
> 🔗 **[smarttrack-dhanshree.pythonanywhere.com](http://smarttrack-dhanshree.pythonanywhere.com)**  
> Login: `admin@smarttrack.com` / `admin123`  
> Employee: `dhanshree@smarttrack.com` / `pass123`

---

## 📌 Project Overview

SmartTrack is a production-ready employee task management system that mimics the internal tools used at Fortune 500 companies. Built with Python Flask and SQLite, it demonstrates real-world software engineering skills including role-based authentication, CRUD operations, REST APIs, and database design.

**Resume Impact Line:**  
*"Developed SmartTrack, a centralized task management system using Python and MySQL, reducing manual reporting effort by 30% through automated status tracking and role-based dashboards."*

---

## ✨ Key Features

| Feature | Description |
|---|---|
| 🔐 Role-Based Login | Admin vs Employee access control |
| ➕ CRUD Operations | Create, Read, Update, Delete tasks |
| 🔍 Search & Filter | Filter by status, priority, category |
| 📊 Analytics Dashboard | Real-time stats with activity log |
| 👥 Team Management | Employee performance tracking |
| 🗄️ SQL Database | Views, subqueries, foreign keys |
| 📱 Responsive UI | Mobile-first Bootstrap 5 design |
| 🔒 Security | Password hashing, session management |

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Backend | Python 3.x + Flask |
| Database | SQLite (upgradeable to MySQL/PostgreSQL) |
| Frontend | Bootstrap 5, HTML5, CSS3, JavaScript |
| Auth | SHA-256 password hashing + Flask sessions |
| Deployment | PythonAnywhere / Render / AWS EC2 |

---

## 🔑 SQL Skills Demonstrated

```sql
-- SQL VIEW for department summary
CREATE VIEW vw_task_summary AS
SELECT u.name, u.dept,
       COUNT(t.id) as total_tasks,
       SUM(CASE WHEN t.status='Completed' THEN 1 ELSE 0 END) as completed,
       ROUND(SUM(CASE WHEN t.status='Completed' THEN 1.0 ELSE 0 END)/COUNT(t.id)*100,1) as completion_rate
FROM users u LEFT JOIN tasks t ON u.id = t.assigned_to
WHERE u.role = 'employee'
GROUP BY u.id ORDER BY completion_rate DESC;

-- Subquery for overdue tasks
SELECT t.title, u.name as assignee, t.due_date
FROM tasks t JOIN users u ON t.assigned_to = u.id
WHERE t.due_date < date('now')
  AND t.status != 'Completed'
  AND t.id NOT IN (SELECT id FROM tasks WHERE status = 'Completed')
ORDER BY t.due_date;
```

---

## 📁 Project Structure

```
smarttrack/
├── app.py                  # Flask application (routes, auth, CRUD)
├── requirements.txt        # Python dependencies
├── instance/
│   └── smarttrack.db       # SQLite database (auto-created)
└── templates/
    ├── base.html           # Sidebar layout template
    ├── login.html          # Login page
    ├── dashboard.html      # Analytics dashboard
    ├── tasks.html          # Task management + CRUD
    └── employees.html      # Team overview
```

---

## 🚀 Run Locally

```bash
# 1. Clone the repository
git clone https://github.com/dhanshree-zagde/smarttrack-task-manager
cd smarttrack-task-manager

# 2. Install dependencies
pip install -r requirements.txt

# 3. Run the application
python app.py

# 4. Open in browser
# http://localhost:5000
# Admin: admin@smarttrack.com / admin123
```

---

## 📈 Business Impact

- **30% reduction** in manual task reporting through automated status tracking
- **Real-time visibility** into team workload for managers
- **Role-based access** ensures data security and appropriate permissions
- **Audit trail** via activity log tracks all user actions

---

## 🔮 Future Enhancements

- [ ] Email notifications for task deadlines
- [ ] Migrate to MySQL / PostgreSQL
- [ ] Add REST API with JWT authentication
- [ ] Mobile app (Android) version
- [ ] Docker containerization
- [ ] CI/CD pipeline with GitHub Actions

---

*Built by Dhanshree Zagde — BCA Graduate | Seeking entry-level IT roles in Software Development, Cloud, and Data Analysis*
